#include <stdio.h>
#include <iostream>
using namespace std;
int main(){
    float x, y;
    cout << "Please input two floats: ";
    cin >> x;
    cin >> y;
    cout << x/y << "\n";
    return 0;
}
