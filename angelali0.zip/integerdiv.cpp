#include <stdio.h>
#include <iostream>
using namespace std;

int main(){
    cout << "Please input 2 integers: ";
    int x;
    int y;
    cin >> x;
    cin >> y;
    cout << x/y << "\n";
    return 0;
}
